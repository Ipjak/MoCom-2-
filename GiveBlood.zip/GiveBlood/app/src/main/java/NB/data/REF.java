package NB.data;

public enum REF {
    ID, LIST, USER
}
